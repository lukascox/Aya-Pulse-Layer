// settings.gradle.kts
rootProject.name = "pulsefit"
include(":app")
